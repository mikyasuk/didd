set linesize 1024;
col owner for a25
col program_name for a45
col program_type for a30
col program_action for a45
col number_of_arguments for a20
set echo on;

alter session set current_schema=EVTMGR;

BEGIN 
  DBMS_SCHEDULER.create_Program (
    program_name        => 'Purge_TB_EVENT_Prg',
    program_type        => 'STORED_PROCEDURE',
    program_action      => 'EVTMGR.PURGE_EVENT_TBL',
    number_of_arguments => 2,
    enabled             => FALSE,
    comments            => 'Program to Execute Stored Procedure PURGE_EVENT_TBL.');

  DBMS_SCHEDULER.define_Program_argument (
    program_name      => 'Purge_TB_EVENT_Prg',
    argument_name     => 'pPurgeRetDay',
    argument_position => 1,
    argument_type     => 'NUMBER',
    default_value     => (5));

  DBMS_SCHEDULER.define_Program_argument (
    program_name      => 'Purge_TB_EVENT_Prg',
    argument_name     => 'pCleanupRetDay',
    argument_position => 2,
    argument_type     => 'NUMBER',
    default_value     => 10);

  DBMS_SCHEDULER.enable (name => 'Purge_TB_EVENT_Prg');
END;

BEGIN
  DBMS_SCHEDULER.create_Program (
    program_name        => 'Purge_TB_PROCESSACTION_Prg',
    program_type        => 'STORED_PROCEDURE',
    program_action      => 'EVTMGR.PURGE_PROCESSACTION_TBL',
    number_of_arguments => 2,
    enabled             => FALSE,
    comments            => 'Program to Execute Stored Procedure PURGE_PROCESSACTION_TBL.');

  DBMS_SCHEDULER.define_Program_argument (
    program_name      => 'Purge_TB_PROCESSACTION_Prg',
    argument_name     => 'pPurgeRetDay',
    argument_position => 1,
    argument_type     => 'NUMBER',
    default_value     => (5));

  DBMS_SCHEDULER.define_Program_argument (
    program_name      => 'Purge_TB_PROCESSACTION_Prg',
    argument_name     => 'pCleanupRetDay',
    argument_position => 2,
    argument_type     => 'NUMBER',
    default_value     => 10);

  DBMS_SCHEDULER.enable (name => 'Purge_TB_PROCESSACTION_Prg');
END;

BEGIN
  DBMS_SCHEDULER.create_Program (
    program_name        => 'Purge_TB_PROCESSCONTROL_Prg',
    program_type        => 'STORED_PROCEDURE',
    program_action      => 'EVTMGR.PURGE_PROCESSCONTROL_TBL',
    number_of_arguments => 2,
    enabled             => FALSE,
    comments            => 'Program to Execute Stored Procedure PURGE_PROCESSCONTROL_TBL.');

  DBMS_SCHEDULER.define_Program_argument (
    program_name      => 'Purge_TB_PROCESSCONTROL_Prg',
    argument_name     => 'pPurgeRetDay',
    argument_position => 1,
    argument_type     => 'NUMBER',
    default_value     => (5));

  DBMS_SCHEDULER.define_Program_argument (
    program_name      => 'Purge_TB_PROCESSCONTROL_Prg',
    argument_name     => 'pCleanupRetDay',
    argument_position => 2,
    argument_type     => 'NUMBER',
    default_value     => 10);

  DBMS_SCHEDULER.enable (name => 'Purge_TB_PROCESSCONTROL_Prg');
END;

-- Display the Program Details.
SELECT owner,program_name,program_type,program_action,number_of_arguments FROM dba_scheduler_Programs where owner='EVTMGR';

