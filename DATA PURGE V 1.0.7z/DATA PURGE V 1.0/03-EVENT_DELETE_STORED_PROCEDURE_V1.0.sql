/*DELETE PROC for EVENT TABLE WHERE LAST_UPDATE_DT < SYSDATE - 5*/
set linesize 1024;
set echo on;

Alter session set current_schema=EVTMGR;
CREATE OR REPLACE PROCEDURE EVTMGR.PURGE_EVENT_TBL (pPurgeRetDay in number, pCleanupRetDay in number) IS
/******************************************************************************
 NAME:	  PURGE_EVENT_TBL
 PURPOSE: Purge EVTMGR.PURGE_EVENT_TBL and Auto-Cleanup Logs Table    

 REVISIONS:
 Ver     Date        Author            Description
 ------  ----------  ----------------  ---------------------------------------
 1.0     03/03/2021  Michael Negassi  1. Created this procedure.

******************************************************************************/
vPrgRetDay	number:=pPurgeRetDay;
vClnRetDay	number:=pCleanupRetDay;
CURSOR tb_cursor IS SELECT * FROM MDMUSR.PROCESSACTION 
WHERE ENTITYEVENTCAT_ID in (1000006, 1000004) AND EVENT_STATUS = 3 AND NEXT_PROCESS_DT > SYSDATE + 999 AND LAST_UPDATE_DT < SYSDATE - vPrgRetDay;
type tb_type is table of MDMUSR.PROCESSACTION%rowtype index by binary_integer;
tb_rec   tb_type;
vPurgeID	number;
vCleanUp	number;
vRowCount	number:=0;
vErr_code	number;
vErr_mesg	varchar2(200);
BEGIN
	  
	vPurgeID := TO_NUMBER(TO_CHAR(sysdate, 'YYMMDDHH24MI'));
	vCleanUp := TO_NUMBER(TO_CHAR(sysdate - vClnRetDay, 'YYMMDDHH24MI'));
	execute immediate 'alter sequence SEQ_EVENT_SID restart start with 1';
	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Begin StoreProcedure "PURGE_EVENT_TBL".');
	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Starting Purge of Table "EVENT". Keeping last '||vPrgRetDay||' Days.');
	commit;
	OPEN tb_cursor;
    LOOP
        fetch tb_cursor bulk collect into tb_rec limit 10000;
	    vRowCount := vRowCount + tb_rec.count;
	    if vRowCount = 0 then raise NO_DATA_FOUND; end if;
	    exit WHEN tb_rec.count=0;
	    forall idx in 1 .. tb_rec.count
         DELETE FROM MDMUSR.EVENT WHERE PROCESSACTION_ID =  tb_rec(idx).PROCESSACTION_ID;
         commit;
    END LOOP;
	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText,RowsDel) values (vPurgeID,'Purge Finished Successfully for Table "EVENT".',vRowCount);
	commit;
	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'About to Cleanup Table "TB_PURGE_EVENT_H". Keeping last '||vClnRetDay||' Days.');
	commit;
	Delete from EVTMGR.TB_PURGE_EVENT_H where to_date(to_char(msgtime,'YYYYMMDD'),'YYYYMMDD') in (select to_date(to_char(msgtime - 10,'YYYYMMDD'),'YYYYMMDD') from EVTMGR.TB_PURGE_EVENT_H);
	commit;
	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Cleanup of Table "TB_PURGE_EVENT_H" Completed Successfully.');
	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'StoreProcedure "PURGE_EVENT_TBL" Exit normally.');
    commit;
     
EXCEPTION
	WHEN NO_DATA_FOUND THEN 
    	insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'No Data Found to be Purge in Table "EVENT"!');
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Purge Finished with Warning for Table "EVENT"!');
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Cleanup of Table "TB_PURGE_EVENT_H" Skipped!');
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'StoreProcedure "PURGE_EVENT_TBL" Exit with Warning!');
		commit;	 
    WHEN OTHERS THEN 
    	vErr_code := SQLCODE;
		vErr_mesg := SUBSTR(SQLERRM, 1 , 200);
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Error during Purge for Table "EVENT"!');
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Error Code: '||vErr_code||'-'||vErr_mesg);
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Purge Finished with ERROR for Table "EVENT"!');
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'Cleanup of Table "TB_PURGE_EVENT_H" Skipped!');
		insert into EVTMGR.TB_PURGE_EVENT_H(PurgeID,MsgText) values (vPurgeID,'StoreProcedure "PURGE_EVENT_TBL" Exit with Error!');
		commit;
  RAISE;
END PURGE_EVENT_TBL;
/