/*DELETE PROC for EVENT TABLE WHERE LAST_UPDATE_DT < SYSDATE - 5*/
set linesize 1024;
set echo on;

Alter session set current_schema=EVTMGR;
CREATE OR REPLACE PROCEDURE EVTMGR.PURGE_PROCESSACTION_TBL (pPurgeRetDay in number, pCleanupRetDay in number) IS
/******************************************************************************
 NAME:	  PURGE_PROCESSACTION_TBL
 PURPOSE: Purge EVTMGR.PURGE_PROCESSACTION_TBL and Auto-Cleanup Logs Table    

 REVISIONS:
 Ver     Date        Author            Description
 ------  ----------  ----------------  ---------------------------------------
 1.0     03/03/2021  Michael Negassi  1. Created this procedure.

******************************************************************************/
vPrgRetDay	number:=pPurgeRetDay;
vClnRetDay	number:=pCleanupRetDay;
CURSOR tb_cursor IS SELECT *  FROM MDMUSR.PROCESSACTION
     WHERE ENTITYEVENTCAT_ID IN (1000006, 1000004) AND EVENT_STATUS = 3 AND NEXT_PROCESS_DT > SYSDATE + 999 AND LAST_UPDATE_DT < SYSDATE - vPrgRetDay;
type tb_type is table of MDMUSR.PROCESSACTION%rowtype index by binary_integer;
tb_rec   tb_type;
vPurgeID	number;
vCleanUp	number;
vRowCount	number:=0;
vErr_code	number;
vErr_mesg	varchar2(200);
BEGIN
	  
	vPurgeID := TO_NUMBER(TO_CHAR(sysdate, 'YYMMDDHH24MI'));
	vCleanUp := TO_NUMBER(TO_CHAR(sysdate - vClnRetDay, 'YYMMDDHH24MI'));
	execute immediate 'alter sequence SEQ_PROCESSACTION_SID restart start with 1';
	insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Begin StoreProcedure "PURGE_PROCESSACTION_TBL".');
	insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Starting Purge of Table "PROCESSACTION". Keeping last '||vPrgRetDay||' Days.');
	commit;
	OPEN tb_cursor;
    LOOP
        fetch tb_cursor bulk collect into tb_rec limit 10000;
	    vRowCount := vRowCount + tb_rec.count;
	    if vRowCount = 0 then raise NO_DATA_FOUND; end if;
	    exit WHEN tb_rec.count=0;
	    forall idx in 1 .. tb_rec.count
         DELETE  FROM MDMUSR.PROCESSACTION WHERE PROCESSACTION_ID=  tb_rec(idx).PROCESSACTION_ID;
         commit;
    END LOOP;
	insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText,RowsDel) values (vPurgeID,'Purge Finished Successfully for Table "PROCESSACTION".',vRowCount);
	commit;
	insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'About to Cleanup Table "TB_PURGE_PROCESSACTION_H". Keeping last '||vClnRetDay||' Days.');
	commit;
	Delete from EVTMGR.TB_PURGE_PROCESSACTION_H where to_date(to_char(msgtime,'YYYYMMDD'),'YYYYMMDD') in (select to_date(to_char(msgtime - 10,'YYYYMMDD'),'YYYYMMDD') from EVTMGR.TB_PURGE_PROCESSACTION_H);
	commit;
	insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Cleanup of Table "TB_PURGE_PROCESSACTION_H" Completed Successfully.');
	insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'StoreProcedure "PURGE_PROCESSACTION_TBL" Exit normally.');
    commit;
     
EXCEPTION
	WHEN NO_DATA_FOUND THEN 
   		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'No Data Found to be Purge in Table "PROCESSACTION"!');
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Purge Finished with Warning for Table "PROCESSACTION"!');
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Cleanup of Table "TB_PURGE_PROCESSACTION_H" Skipped!');
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'StoreProcedure "PURGE_PROCESSACTION_TBL" Exit with Warning!');
		commit;	 
    WHEN OTHERS THEN 
   		vErr_code := SQLCODE;
		vErr_mesg := SUBSTR(SQLERRM, 1 , 200);
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Error during Purge for Table "PROCESSACTION"!');
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Error Code: '||vErr_code||'-'||vErr_mesg);
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Purge Finished with ERROR for Table "PROCESSACTION"!');
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'Cleanup of Table "TB_PURGE_PROCESSACTION_H" Skipped!');
		insert into EVTMGR.TB_PURGE_PROCESSACTION_H(PurgeID,MsgText) values (vPurgeID,'StoreProcedure "PURGE_PROCESSACTION_TBL" Exit with Error!');
		commit;
   RAISE;
END PURGE_PROCESSACTION_TBL;
/