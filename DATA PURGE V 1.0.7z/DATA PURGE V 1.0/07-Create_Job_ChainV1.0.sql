/*<TOAD_FILE_CHUNK>*/
set linesize 1024;
col owner  for a20
col job_name  for a50
col program_name  for a50
col schedule_name  for a50
col start_date for a35
col end_date  for a35
col enabled  for a20
set echo on;

alter session set current_schema=EVTMGR;
BEGIN
  DBMS_SCHEDULER.CREATE_CHAIN (
   chain_name            =>  'DATA_PURGE_EVENT_MANAGER_JOBCHAIN',
   rule_set_name         =>  NULL,
   evaluation_interval   =>  NULL,
   comments              =>  NULL);
END;
/


--- define three steps for this chain. Referenced programs must be enabled.
BEGIN
 DBMS_SCHEDULER.DEFINE_CHAIN_STEP('DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'step1', 'Purge_TB_EVENT_Prg');
 DBMS_SCHEDULER.DEFINE_CHAIN_STEP('DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'step2', 'Purge_TB_PROCESSACTION_Prg');
 DBMS_SCHEDULER.DEFINE_CHAIN_STEP('DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'step3', 'Purge_TB_PROCESSCONTROL_Prg');
END;
/

--- define corresponding rules for the chain.
BEGIN
 DBMS_SCHEDULER.DEFINE_CHAIN_RULE('DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'TRUE', 'START step1');
 DBMS_SCHEDULER.DEFINE_CHAIN_RULE (
   'DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'step1 SUCCEEDED', 'Start step2');
    DBMS_SCHEDULER.DEFINE_CHAIN_RULE (
   'DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'step2 SUCCEEDED', 'Start step3');
 DBMS_SCHEDULER.DEFINE_CHAIN_RULE (
   'DATA_PURGE_EVENT_MANAGER_JOBCHAIN', 'step3 SUCCEEDED', 'END');
END;
/

--- enable the chain
BEGIN
 DBMS_SCHEDULER.ENABLE('DATA_PURGE_EVENT_MANAGER_JOBCHAIN');
END;
/

--- create a chain job to start the chain daily at 1:00 p.m.
BEGIN
 DBMS_SCHEDULER.CREATE_JOB (
   job_name        => 'DATA_PURGE_EVENT_MANAGER_JOB',
   job_type        => 'CHAIN',
   job_action      => 'DATA_PURGE_EVENT_MANAGER_JOBCHAIN',
   repeat_interval => 'freq=daily; byhour=22; byminute=30; bysecond=0;',
   enabled         => TRUE);
END;
/

