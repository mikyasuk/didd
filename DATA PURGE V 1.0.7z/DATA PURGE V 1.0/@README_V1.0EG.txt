==========================================================================================================================================
'                                             Create Program and Schedule Job to Purge EVENT MANAGER Tables                                             '
'                                                          EVENT, PROCESSACTION,PROCESSCONTROL                                                         '
'                                                                COOKBOOK                                                                '
==========================================================================================================================================

   - Note that the Purge tables has dependeny on each other to purge older data so Job Chains are implemented.




   - Prerequisite's Activities (OUTSIDE Downtime Period)
     --------------------------------------------
       PR01.0- GET FAMILLAR WITH THIS PROCEDURES BEFORE IMPLEMENTATION DATE
       PR02.0- Validate you have all required Scripts ready for the Implementation. Here is the list of Scripts and Descriptions:
			- 00-Create_UserV1.0.sql          			 		 --> Create EVTMGR user to own and execute the database objects
            - 01-Create_SequenceV1.0.sql       					 --> Create an Oracle Sequence used by TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H Tables.
            - 02-Create_TableV1.0.sql          					 --> Create TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H Tables.
            - 03-EVENT_DELETE_STORED_PROCEDURE_V1.0.sql  		 --> Create Stored Procedure Responsible to Purge MDMUSR.EVENT and CleanUP EVTMGR.TB_PURGE_EVENT_H Tables.
			- 04-PROCESSACTION_DELETE_STORED_PROCEDURE_V1.0.sql  --> Create Stored Procedure Responsible to Purge MDMUSR.PROCESSACTION and CleanUP EVTMGR.TB_PURGE_PROCESSACTION_H Tables.
			- 05-PROCESSCONTROL_DELETE_STORED_PROCEDURE_V1.0.sql --> Create Stored Procedure Responsible to Purge MDMUSR.PROCESSCONTROL and CleanUP EVTMGR.TB_PURGE_PROCESSCONTROL_H Tables.
            - 06-Create_Job_ProgramV1.0.sql     --> Create a Wrapper for SP PURGE_EVENT_TBL, PURGE_PROCESSACTION_TBL, PURGE_PROCESSCONTROL_TBL and Set Purge and CleanUp Parameters.
            - 07-Create_Job_ChainV1.0.sql   --> Create a Job Chain and job that Define Execution Frequency for Purge Programs and the task steps.
            - 08-TEST_DATA_PURGE_V1.0.sql       --> check the purge is successful in the EVENT MANAGER Tables
       PR03.0- Modify Scripts According to your Requirements.  Set the proper Values for:
       PR03.1  - 06-Create_Job_ProgramV1.0.sql  --> Set the Number of Rentention Days for EVENT, PROCESSACTION, PROCESSCONTROL(pPurgeRetDay) and TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H (pCleanupRetDay)
       PR03.2  - 07-Create_Job_ScheduleV1.0.sql --> Set 'repeat_interval' (Frequency) Value for this Job, using provided exemples in Script
       PR04.0- Put all Scripts in a Specific Folder, Reachable by your SQL Tool (TOAD, SQLPlus, SQLDevelopper,etc.)
       ------------------------------------------------------------------------------------------------------------------------------


   - Implementation DBA Activities (Downtime Period)
     --------------------------------------------
X	   IA00.0- create EVTMGR user using the below command.
	   IA00.1     -- SQL> @/<Script_Path>/03-00-Create_UserV1.0.sql;
X      IA01.0- Manually Confirm Access is Allowed to Table MDMUSR.EVENT, MDMUSR.PROCESSACTION, MDMUSR.PROCESSCONTROL --> How?
       IA02.0- Execute This Following SQL Commands to Backup MDMUSR.EVENT, MDMUSR.PROCESSACTION, MDMUSR.PROCESSCONTROL Tables
       IA02.1   - SQL> create table EVTMGR.EVENT_BAK as select * from MDMUSR.EVENT;
	   IA02.2   - SQL> create table EVTMGR.PROCESSACTION_BAK as select * from MDMUSR.PROCESSACTION;
	   IA02.3   - SQL> create table EVTMGR.PROCESSCONTROL_BAK as select * from MDMUSR.PROCESSCONTROL;
       IA03.0- Execute This Following SQL Script to create required Oracle Sequences
       IA03.1   - SQL> @/<Script_Path>/01-Create_SequenceV1.0.sql;
       IA04.0- Execute This Following SQL Script to create TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H Table
       IA04.1   - SQL> @/<Script_Path>/02-Create_TableV1.0.sql;
       IA05.0- Execute This Following SQL Script to create PURGE_EVENT_TBL, PURGE_PROCESSACTION_TBL, PURGE_PROCESSCONTROL_TBL Stored Procedure
       IA05.1  - SQL> @/<Script_Path>/03-EVENT_DELETE_STORED_PROCEDURE_V1.0.sql;
	   IA05.1  - SQL> @/<Script_Path>/04-PROCESSACTION_DELETE_STORED_PROCEDURE_V1.0.sql;
	   IA05.1  - SQL> @/<Script_Path>/05-PROCESSCONTROL_DELETE_STORED_PROCEDURE_V1.0.sql;
       IA06.0- Validate you have The Most Recent '06-Create_Job_ProgramVx.x.sql' Script in your Folder
       IA06.1- Execute This SQL Script to create Program Named 'Purge_TB_EVENT_Prg', 'Purge_TB_PROCESSACTION_Prg', 'Purge_TB_PROCESSCONTROL_Prg'
       IA06.2  - SQL> @/<Script_Path>/06-Create_Job_ProgramVx.x.sql;
       IA07.0- Validate you have The Most Recent '07-Create_Job_ChainVx.x.sql' Script in your Folder
       IA07.1- Execute This SQL Script to create Job Chain Named 'DATA_PURGE_EVENT_MANAGER_JOBCHAIN' and a Job named , 'DATA_PURGE_EVENT_MANAGER_JOB'
                 - Note: Job is created Deliberatly in Disable State. State will be set to Enable later in this Procedure.
       ------------------------------------------------------------------------------------------------------------------------------


   - Validation Activities (Downtime Period)
     --------------------------------------------
       VA01.0- Execute These SQL Commands to Confirm All Objects are Valid for User 'EVTMGR'
       VA01.1  - SQL> set linesize 1024
       VA01.2  - SQL> col object_name for a50
       VA01.3  - SQL> set echo on
X      VA01.4  - SQL> select object_name,object_type,status from dba_objects* where  owner='EVTMGR';
       VA02.0- If Invalid Objects are Found, Investigate and Fix the Situation. Evaluate if a Rollback is Required.
X      VA03.0- Execute This Following SQL Command to Manually Run and Test The Purge Job that follow the chain rules 'DATA_PURGE_EVENT_MANAGER_JOB'
X      VA03.1  - SQL> exec DBMS_SCHEDULER.run_job (job_name => 'EVTMGR.DATA_PURGE_EVENT_MANAGER_JOB', use_current_session => TRUE*);
       VA04.0- *IF REQUIRED* You can Stop the Job by issuing This Following SQL Command
       VA04.1  - SQL> exec DBMS_SCHEDULER.stop_job (job_name => 'EVTMGR.DATA_PURGE_EVENT_MANAGER_JOB', force => TRUE);
	   VA05.0- Confirm Execution Resultats with These SQL Commands
       VA05.1  - SQL> set linesize 1024
       VA05.2  - SQL> col msgtext for a100
       VA05.3  - SQL> set echo on
       VA05.4  - SQL> select * from EVTMGR.TB_PURGE_EVENT_H order by purgeid desc, lineid asc;
	   VA05.4  - SQL> select * from EVTMGR.TB_PURGE_PROCESSACTION_H order by purgeid desc, lineid asc;
	   VA05.4  - SQL> select * from EVTMGR.TB_PURGE_PROCESSCONTROL_H order by purgeid desc, lineid asc;
	  
                 - Notes:
                   - By Design, We Decided to include the Clean Up Fonctionality to Clean The Table 'TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H' and Purge of 'MDMUSR.EVENT', 'MDMUSR.PROCESSACTION' ,'MDMUSR.PROCESSCONTROL' in all the StoredProcedurs.
                   - By Design, to Prevent any Lost of Important Messages, No Clean Up of Table 'TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H' when No Data is Found to be Purge in 'MDMUSR.EVENT', 'MDMUSR.PROCESSACTION' ,'MDMUSR.PROCESSCONTROL'.
       ------------------------------------------------------------------------------------------------------------------------------


   - Go/No Go Decision (Downtime Period)
     --------------------------------------------
       GN01.0- If All Worked Well and Job Ran Successfully, Execute This SQL Command to Enable Job. Otherwise, Go to Rollback Section.
       GN01.1  - SQL> exec dbms_scheduler.enable('EVTMGR.DATA_PURGE_EVENT_MANAGER_JOB');
       GN02.0- Drop Backup Table 'EVTMGR.EVENT_BAK', 'EVTMGR.PROCESSACTION_BAK', 'EVTMGR.PROCESSCONTROL_BAK'
       GN03.0- Allow Access to Table 'MDMUSR.EVENT', 'MDMUSR.PROCESSACTION' ,'MDMUSR.PROCESSCONTROL' 
               - Note: THIS IS THE END OF THE DOWNTIME PERIOD!
       ------------------------------------------------------------------------------------------------------------------------------


   - Post-Implementation Activities (After Downtime Period)
     --------------------------------------------
       PM01.0- Monitor Job is Next Scheduled Execution
       PM02.0- Enjoy your New Accomplishment!
       ------------------------------------------------------------------------------------------------------------------------------


   - Rollback Activites
     --------------------------------------------

       If any issue Forces you to Rollback, Follow the Next Steps:

        RA01.0- *IF REQUIRED* You can Stop the Job by issuing This Following SQL Command
        RA01.1   - SQL> exec DBMS_SCHEDULER.stop_job (job_name => 'EVTMGR.DATA_PURGE_EVENT_MANAGER_JOB', force => TRUE);
	    RA02.0- Drop The Job 'EVTMGR.JOB_RUN_PURGE_TABLE_PRG'
        RA02.1   - SQL> exec DBMS_SCHEDULER.drop_job (job_name => 'EVTMGR.DATA_PURGE_EVENT_MANAGER_JOB');
	    RA03.0- Drop The Job Chain 'DATA_PURGE_EVENT_MANAGER_JOBCHAIN'
        RA03.1   - SQL> exec DBMS_SCHEDULER.drop_chain ( chain_name => 'DATA_PURGE_EVENT_MANAGER_JOBCHAIN',force => TRUE); 
	    RA04.0- Drop The Programs 'EVTMGR.PURGE_TB_EVENT_PRG', 'EVTMGR.PURGE_TB_PROCESSACTION_PRG', 'EVTMGR.PURGE_TB_PROCESSCONTROL_PRG'
        RA04.1  - SQL> exec DBMS_SCHEDULER.drop_program (program_name => 'EVTMGR.PURGE_TB_EVENT_PRG',force => TRUE);
		RA04.2  - SQL> exec DBMS_SCHEDULER.drop_program (program_name => 'EVTMGR.PURGE_TB_PROCESSACTION_PRG',force => TRUE);
		RA04.3  - SQL> exec DBMS_SCHEDULER.drop_program (program_name => 'EVTMGR.PURGE_TB_PROCESSCONTROL_PRG',force => TRUE);
        RA05.0- Drop The Stored Procedures 'EVTMGR.PURGE_EVENT_TBL', 'EVTMGR.PURGE_PROCESSACTION_TBL', 'EVTMGR.PURGE_PROCESSCONTROL_TBL'
        RA05.1   - SQL> drop procedure EVTMGR.PURGE_EVENT_TBL;
		RA05.2   - SQL> drop procedure EVTMGR.PURGE_PROCESSACTION_TBL;
		RA05.3   - SQL> drop procedure EVTMGR.PURGE_PROCESSCONTROL_TBL;
        RA06.0- Drop The Tables 'EVTMGR.TB_PURGE_EVENT_H, TB_PURGE_PROCESSACTION_H, TB_PURGE_PROCESSCONTROL_H'
        RA06.1   - SQL> drop table EVTMGR.TB_PURGE_EVENT_H cascade constraints;
		RA06.2   - SQL> drop table TB_PURGE_PROCESSACTION_H cascade constraints;
		RA06.3   - SQL> drop table TB_PURGE_PROCESSCONTROL_H cascade constraints;
        RA07.0- Drop The Sequence 'EVTMGR.SEQ_EVENT_SID', 'EVTMGR.SEQ_PROCESSACTION_SID', 'EVTMGR.SEQ_PROCESSCONTROL_SID'
        RA07.1  - SQL> drop sequence EVTMGR.SEQ_EVENT_SID;
		RA07.2  - SQL> drop sequence EVTMGR.SEQ_PROCESSACTION_SID;
		RA07.3  - SQL> drop sequence EVTMGR.SEQ_PROCESSCONTROL_SID;
        RA08.0- Repopulate Table 'EVTMGR.EVENT' with Data in Backup Table 'EVTMGR.EVENT_BAK'
		RA08.1- Repopulate Table 'EVTMGR.PROCESSACTION' with Data in Backup Table 'EVTMGR.PROCESSACTION_BAK'
		RA08.2- Repopulate Table 'EVTMGR.PROCESSCONTROL' with Data in Backup Table 'EVTMGR.PROCESSCONTROL_BAK'
        RA09.0- Drop Backup Table 'EVTMGR.EVENT_BAK', EVTMGR.PROCESSACTION_BAK', 'EVTMGR.PROCESSCONTROL_BAK'
---         ------------------------------------------------------------------------------------------------------------------------------
                                                    

-------------------------------------------------------------END OF COOKBOOK--------------------------------------------------------------

QUICK REFERENCES:
----------------
--Drop Program
exec DBMS_SCHEDULER.drop_program (program_name => 'owner.program_name',force => TRUE);

--Drop Chain
exec DBMS_SCHEDULER.drop_chain ( chain_name => 'owner.chain_name',force => TRUE); 

--Drop Schedule
exec DBMS_SCHEDULER.drop_schedule (schedule_name => 'owner.schedule_name',force => TRUE);

--Job Enable/Disable
exec dbms_scheduler.enable('owner.job_name');
exec dbms_scheduler.disable('owner.job_name');

--Run/Stop & Drop Job Manually
exec DBMS_SCHEDULER.run_job (job_name => 'owner.job_name', use_current_session => TRUE);
exec DBMS_SCHEDULER.stop_job (job_name => 'owner.job_name',force => TRUE);
exec DBMS_SCHEDULER.drop_job (job_name => 'owner.job_name');

--Getting infos from Running Jobs
select * from dba_scheduler_running_jobs;

------------------------------------------------------------------------------------------------------------------------------------------
CookBook: Program Creation & Job Scheduling (V1.0en)
Michael E Negassi
------------------------------------------------------------------------------------------------------------------------------------------