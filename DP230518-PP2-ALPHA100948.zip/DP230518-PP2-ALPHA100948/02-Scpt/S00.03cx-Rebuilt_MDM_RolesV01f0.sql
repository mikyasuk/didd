@U:\Mcp_Refresh\DP230518-PP2-ALPHA100948\05-Wrap\cx220225_HDR_WrpV1015.sql  'S00.03cx-Rebuilt_MDM_RolesV01f0'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
SET echo		off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Grants to RL_MDMUSR_READONLY and RL_MDMUSR_READWRITE
PROMPT ----------------------------------------------------------------------------------------------;
SET echo		off;
DECLARE
grant_RO_str varchar2(500);
grant_RW_str varchar2(500);
trg_schema varchar2(30) := upper('MDMUSR');
trg_RO_role varchar2(30) := upper('RL_MDMUSR_READONLY');
trg_RW_role varchar2(30) := upper('RL_MDMUSR_READWRITE');
BEGIN
	FOR cur_rec IN (SELECT table_name FROM dba_tables where owner = ''||trg_schema||'' order by table_name) LOOP
		BEGIN
			grant_RO_str:='GRANT SELECT ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RO_role;
			grant_RW_str:='GRANT SELECT, INSERT,UPDATE,DELETE ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RW_role;
			execute immediate grant_RO_str;
			execute immediate grant_RW_str;
		END;
	END LOOP;
	dbms_output.put_line('Grants to '||trg_RO_role||' and '||trg_RW_role||' Completed Successfully!');
END;
/

SET echo		on;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Grants to RL_MDMPUB_READONLY and RL_MDMPUB_READWRITE
PROMPT ----------------------------------------------------------------------------------------------;
SET echo		off;
DECLARE
grant_RO_str varchar2(500);
grant_RW_str varchar2(500);
trg_schema varchar2(30) := upper('MDMPUB');
trg_RO_role varchar2(30) := upper('RL_MDMPUB_READONLY');
trg_RW_role varchar2(30) := upper('RL_MDMPUB_READWRITE');
BEGIN
	FOR cur_rec IN (SELECT table_name FROM dba_tables where owner = ''||trg_schema||'' order by table_name) LOOP
		BEGIN
			grant_RO_str:='GRANT SELECT ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RO_role;
			grant_RW_str:='GRANT SELECT, INSERT,UPDATE,DELETE ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RW_role;
			execute immediate grant_RO_str;
			execute immediate grant_RW_str;
		END;
	END LOOP;
	execute immediate 'GRANT SELECT ON MDMPUB.KAFKA_EVENT_FULL_PROF_SID  to RL_MDMPUB_READONLY, RL_MDMPUB_READWRITE';
	execute immediate 'GRANT SELECT ON MDMPUB.KAFKA_LATEST_FULL_PROF_SID  to RL_MDMPUB_READONLY, RL_MDMPUB_READWRITE';
	execute immediate 'GRANT SELECT ON MDMPUB.THINPUB_SID to RL_MDMPUB_READONLY, RL_MDMPUB_READWRITE';
	dbms_output.put_line('Grants to '||trg_RO_role||' and '||trg_RW_role||' Completed Successfully!');
END;
/

SET echo		on;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Grants to RL_MCPSRCH_READONLY
PROMPT ----------------------------------------------------------------------------------------------;
SET feedback	off;
SET echo		off;
GRANT SELECT ON MDMUSR.ADDRESS TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.ADDRESSGROUP TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.ALERT TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.CDALERTCAT TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.CDALERTTP TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.CONTACT TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.CONTACTMETHOD TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.CONTACTMETHODGROUP TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.CONTEQUIV TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.IDENTIFIER TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.LOCATIONGROUP TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.ORG TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.ORGNAME TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.PERSON TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.PERSONNAME TO RL_MCPSRCH_READONLY;
GRANT SELECT ON MDMUSR.PHONENUMBER TO RL_MCPSRCH_READONLY;
exec dbms_output.put_line('Grants to RL_MCPSRCH_READONLY Completed Successfully!');

CREATE OR REPLACE SYNONYM MCPSRCH.ADDRESS FOR MDMUSR.ADDRESS;
CREATE OR REPLACE SYNONYM MCPSRCH.ADDRESSGROUP FOR MDMUSR.ADDRESSGROUP;
CREATE OR REPLACE SYNONYM MCPSRCH.CONTACT FOR MDMUSR.CONTACT;
CREATE OR REPLACE SYNONYM MCPSRCH.CONTACTMETHOD FOR MDMUSR.CONTACTMETHOD;
CREATE OR REPLACE SYNONYM MCPSRCH.CONTACTMETHODGROUP FOR MDMUSR.CONTACTMETHODGROUP;
CREATE OR REPLACE SYNONYM MCPSRCH.CONTEQUIV FOR MDMUSR.CONTEQUIV;
CREATE OR REPLACE SYNONYM MCPSRCH.IDENTIFIER FOR MDMUSR.IDENTIFIER;
CREATE OR REPLACE SYNONYM MCPSRCH.LOCATIONGROUP FOR MDMUSR.LOCATIONGROUP; 
CREATE OR REPLACE SYNONYM MCPSRCH.ORG FOR MDMUSR.ORG;
CREATE OR REPLACE SYNONYM MCPSRCH.ORGNAME FOR MDMUSR.ORGNAME;
CREATE OR REPLACE SYNONYM MCPSRCH.PERSON FOR MDMUSR.PERSON;
CREATE OR REPLACE SYNONYM MCPSRCH.PERSONNAME FOR MDMUSR.PERSONNAME; 
CREATE OR REPLACE SYNONYM MCPSRCH.PHONENUMBER FOR MDMUSR.PHONENUMBER;

set echo off;
@U:\Mcp_Refresh\DP230518-PP2-ALPHA100948\05-Wrap\cx220225_FTR_WrpV1015.sql;
