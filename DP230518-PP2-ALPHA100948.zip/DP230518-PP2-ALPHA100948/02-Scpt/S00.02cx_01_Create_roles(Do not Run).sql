--no need to recreate roles
create role RL_MDMUSR_READONLY;

create role RL_MDMUSR_READWRITE;

create role RL_MDMPUB_READONLY;

create role RL_MDMUSR_READWRITE;