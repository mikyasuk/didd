@U:\Mcp_Refresh\DP230518-PP2-ALPHA100948\05-Wrap\cx220225_HDR_WrpV1015.sql  'S00.05cx-Upd_MDM_StatsV01f0'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMUSR;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Gather_Schema_Stats;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;

--exec dbms_stats.gather_database_stats(degree => 16, cascade => TRUE);
exec dbms_stats.gather_schema_stats('MDMUSR',degree => 16);
exec dbms_stats.gather_schema_stats('MDMPUB',degree => 16);

set echo off;
@U:\Mcp_Refresh\DP230518-PP2-ALPHA100948\05-Wrap\cx220225_FTR_WrpV1015.sql;
