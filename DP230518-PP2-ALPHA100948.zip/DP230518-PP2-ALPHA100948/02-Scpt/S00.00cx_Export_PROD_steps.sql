
-- sur serveur prod

--1
cat > /dbaapp/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub.par <<EOF
directory=DATA_PUMP_BKP
SCHEMAS=MDMUSR,MDMPUB
dumpfile=exp_mdmusr_mdmpub_%u.dmp
logfile=export_mdmusr_mdmpub.log
flashback_time=systimestamp
parallel=16
reuse_dumpfiles=yes
exclude=statistics
exclude=grant
exclude=table:"like 'APP%'"
exclude=table:"like 'H_APP%'"
exclude=table:"like 'CONFIG%'"
exclude=table:"like 'H_CONFIG%'"
exclude=table:"like 'SIB%'"
--EOF

sudo /bin/chmod go+rw /dbaapp/mcp/operation/pomdmdbc/par/exp_mdmusr_mdmpub.par

--2
sqlplus admin/********@pomdmdbc_rw

    alter system set undo_retention = 5400;    quit;

--3
expdp admin/*******@RACPRD04-SCAN.PRD.BNGF.LOCAL/pomdmdbc_rw.PRD.BNGF.LOCAL  encryption_password=Encr_pwd parfile=/dbaapp/mcp/operation/pomdmdbc/par/exp_mdmusr_mdmpub.par &

--4
sqlplus admin/**********@pomdmdbc_rw

    alter system set undo_retention = 900;    quit;


expdp in background


replace xxxxxxxx by admin password


--ATA TEAM Can Help Copy the files
Please copy the below files in PROD Jump server  LRPCCDBMGT0236 to PP Jump server LRTCCDBMGT1171

Source;  PROD Jump server  LRPCCDBMGT0236

  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_01.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_02.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_03.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_04.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_05.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_06.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_07.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_08.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_09.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_10.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_11.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_12.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_13.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_14.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_15.dmp
  /mnt/PMG0000EXACCLON02/mcp/operation/pomdmdbc/exp_mdmusr_mdmpub_16.dmp


 
 Destinsation: PP Jump server LRTCCDBMGT1171
 /mnt/EMG0000EXACCDRU02/temp