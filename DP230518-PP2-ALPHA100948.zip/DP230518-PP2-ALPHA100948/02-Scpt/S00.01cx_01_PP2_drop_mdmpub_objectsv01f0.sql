@U:\Mcp_Refresh\DP230518-PP2-ALPHA100948\05-Wrap\cx220225_HDR_WrpV1015.sql  'S00.01cx_01_PP2_drop_mdmpub_objectsv01f0'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Clear scheam objects MDMPUB;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;

DECLARE
drop_str varchar2(500);
trg_schema varchar2(30) := upper('MDMPUB');
ownercount number;
BEGIN
        -- Materialized view log 
        select count(log_owner) into ownercount from dba_mview_logs where upper(log_owner) = ''||trg_schema||'';
        IF (ownercount > 0) then
           FOR cur_record IN (SELECT MASTER from dba_mview_logs where upper(LOG_owner) = ''||trg_schema||'') 
           LOOP
                    drop_str:='DROP MATERIALIZED VIEW LOG ON ' ||trg_schema||'.' || cur_record.MASTER;
                    dbms_output.put_line(drop_str);
                    execute immediate drop_str;
            END LOOP;               
        END IF;        
        
        -- Materialized view
        select count(owner) into ownercount from dba_mviews where upper(owner) = ''||trg_schema||'';
        IF (ownercount > 0) then
           FOR cur_recmv IN (SELECT MVIEW_NAME from dba_mviews where upper(owner) = ''||trg_schema||'') 
           LOOP
                    drop_str:='DROP MATERIALIZED VIEW ' ||trg_schema||'.' || cur_recmv.MVIEW_NAME;
                    dbms_output.put_line(drop_str);
                    execute immediate drop_str;
            END LOOP;               
        END IF;        

        FOR cur_rec IN (SELECT object_name, object_type 
                  FROM   dba_objects where owner = ''||trg_schema||'' 
                  and  object_type IN ('TABLE', 'VIEW', 'PACKAGE', 'PROCEDURE', 'FUNCTION', 'SEQUENCE','SYNONYM')
                  order by object_type desc) LOOP
                  
            BEGIN
              IF cur_rec.object_type = 'TABLE' THEN
               drop_str:='DROP '  || cur_rec.object_type ||' ' ||trg_schema||'.' || cur_rec.object_name || ' CASCADE CONSTRAINTS PURGE';
              dbms_output.put_line(drop_str);
              execute immediate drop_str;
              ELSE
                drop_str:='DROP ' || cur_rec.object_type || ' ' ||trg_schema||'.'|| cur_rec.object_name;
              dbms_output.put_line(drop_str);
               execute immediate drop_str;
              END IF;
            END;
        END LOOP;
EXCEPTION
     WHEN NO_DATA_FOUND THEN
     NULL;
END;
/

set echo off;
@U:\Mcp_Refresh\DP230518-PP2-ALPHA100948\05-Wrap\cx220225_FTR_WrpV1015.sql;
