﻿set escchar off escape off echo off termout off feedback off show off verify off trim off trims off linesize 114 serveroutput on size unlimited;
col cLogFile new_v gLogFile;
col cSpcChr new_v gSpcChr;
col cHdrL new_v vHdrL;
col cHdrM new_v vHdrM;
col cHdrR new_v vHdrR;
define vScptNme = "'&1'";
define gSlshCar = "'\'";
define gDirPath = "'U:\MCP_Deployment\DP270523-PR-ALPHA102085\'";
define gLogPath = "'U:\MCP_Deployment\DP270523-PR-ALPHA102085\03-Logs\'";
alter session set nls_date_format='YY-MM-DD HH24:MI:SS';
select &gLogPath.||&vScptNme.||'~'||TO_CHAR(SYSDATE + interval '1' minute, 'YY"-"MM"-"DD_HH24"h"MI')||'.log' cLogFile, chr(10) cSpcChr,
upper(sys_context('USERENV','CON_NAME'))||'('||decode(upper(sys_context('USERENV','DATABASE_ROLE')),'PRIMARY','RW','RO')||'): ' cHdrL,
'USER('||(case when sys_context('USERENV','CURRENT_USER') = 'SYS' then rpad('&_USER. as SYSDBA',18) else rpad('&_USER.',18) end)||') SID('||lpad(sys_context('USERENV','UNIFIED_AUDIT_SESSIONID'),10)||') "On ' cHdrM,
(case when '&_O_VERSION.' like '%Extreme%' then 'Exacc' else ' AIX ' end)||' With Oracle V'||'&_O_RELEASE.'||'" --> ' cHdrR
from dual;
set termout on;
SPOOL "&gLogFile.";
select rpad('&vHdrL.'||'&vHdrM.'||'&vHdrR.'||sysdate,114) as " " from dual;
PROMPT ------------------------------------------------------------------------------------------------------------------;
set head off;
select rpad('Running Script: '||&vScptNme.||'.sql',114) as " " from dual;
PROMPT ------------------------------------------------------------------------------------------------------------------;
set linesize 2000 pagesize 2000 long 5000 head on feedback on trim on trims on echo off;
PROMPT -- Set Session Parameters;
PROMPT ------------------------------------------------------------------------------------------------------------------;
set echo on;
WHENEVER OSERROR EXIT 9;
--WHENEVER SQLERROR CONTINUE;
alter session set nls_length_semantics='CHAR';
alter session force parallel dml   parallel 16;
alter session force parallel query parallel 16;
set echo off;
PROMPT ------------------------------------------------------------------------------------------------------------------;
PROMPT &gSpcChr.;
