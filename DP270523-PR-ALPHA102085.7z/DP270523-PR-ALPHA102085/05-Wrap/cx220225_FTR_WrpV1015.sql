﻿set echo off;
set head on feedback off timing off trim off trims off linesize 114;
select rpad('&vHdrL.'||'&vHdrM.'||'&vHdrR.'||sysdate,114) as " " from dual;
PROMPT ------------------------------------------------------------------------------------------------------------------;
SPOOL OFF;
