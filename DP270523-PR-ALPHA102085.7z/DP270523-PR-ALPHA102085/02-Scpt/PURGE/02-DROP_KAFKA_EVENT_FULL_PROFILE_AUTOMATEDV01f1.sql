@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  '02-DROP_KAFKA_EVENT_FULL_PROFILE_AUTOMATEDV01f1'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
DECLARE
DROP_KAFKA_EVENT_FULL_PROFILE varchar2(500);
tb_schema varchar2(30) := upper('MDMPUB');
tb_KAFKA_EVENT_FULL_PROFILE varchar2(30) := upper('KAFKA_EVENT_FULL_PROFILE');

BEGIN
DBMS_OUTPUT.ENABLE(1000000);
	FOR cur_rec IN (select partition_name from (WITH date_partition AS (
select partition_name,
  TO_DATE(substr(high_value,11,11),'YYYY-MM-DD') high_value from ( SELECT
    partition_name,
    extractvalue(dbms_xmlgen.getxmltype('select high_value
       FROM   dba_TAB_PARTITIONS WHERE table_name = '''
        || t.table_name
        || ''' and PARTITION_NAME = '''
        || t.partition_name
        || ''''),'//text()') AS high_value
FROM
    dba_tab_partitions t
   WHERE TABLE_NAME = ''||tb_KAFKA_EVENT_FULL_PROFILE||'' and table_owner = ''||tb_schema||'')
 ) 
  (SELECT
  partition_name,
   high_value
FROM
date_partition where HIGH_VALUE < SYSDATE -60  and partition_name like '%SYS%'
) order by HIGH_VALUE))
 LOOP
		BEGIN
			DROP_KAFKA_EVENT_FULL_PROFILE:='ALTER TABLE  ' ||tb_schema||'.'|| tb_KAFKA_EVENT_FULL_PROFILE || ' DROP PARTITION '|| cur_rec.partition_name;
			execute immediate DROP_KAFKA_EVENT_FULL_PROFILE;
		END;
		dbms_output.put_line(cur_rec.partition_name ||' Dropped Successfully!');
	END LOOP;
END;
/
ALTER INDEX IX_KAFKA_EVENT_FULL_PRO_01 REBUILD;
ALTER INDEX IX_KAFKA_EVENT_FULL_PRO_02 REBUILD;
ALTER INDEX IX_KAFKA_EVENT_FULL_PRO_04 REBUILD;
ALTER INDEX IX_KAFKA_EVENT_FULL_PRO_03 REBUILD;
ALTER INDEX IX_KAFKA_EVENT_FULL_PRO_05 REBUILD;
    
 set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;
