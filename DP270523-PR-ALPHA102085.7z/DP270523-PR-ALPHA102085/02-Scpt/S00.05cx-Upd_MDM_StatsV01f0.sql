/* Formatted on 6/8/2022 1:13:43 PM (QP5 v5.336) */
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S00.05cx-Upd_MDM_StatsV01f0'
SET ECHO OFF;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
SET ECHO ON;
WHENEVER SQLERROR CONTINUE;
ALTER SESSION DISABLE PARALLEL DML;
ALTER SESSION DISABLE PARALLEL QUERY;
ALTER SESSION SET NLS_LENGTH_SEMANTICS = 'CHAR';
ALTER SESSION SET CURRENT_SCHEMA = MDMUSR;
SET ECHO OFF;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Gather_Schema_Stats;
PROMPT ----------------------------------------------------------------------------------------------;
SET ECHO ON;

--exec dbms_stats.gather_database_stats(degree => 16, cascade => TRUE);
EXEC dbms_stats.gather_schema_stats('MDMUSR',degree => 16);
EXEC dbms_stats.gather_schema_stats('MDMPUB',degree => 16);

SET ECHO OFF;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;