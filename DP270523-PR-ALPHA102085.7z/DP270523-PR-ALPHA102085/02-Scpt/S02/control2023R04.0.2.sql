prompt "Start of 2023 R04.0.2"
/

@ALPHA-91750-DML.sql
@ALPHA-66363_DML.sql
@ALPHA-78439_DML.sql
@ALPHA-97189_DML.sql
@ALPHA-97593_DML.sql

prompt "End of 2023 R04.0.2"
/