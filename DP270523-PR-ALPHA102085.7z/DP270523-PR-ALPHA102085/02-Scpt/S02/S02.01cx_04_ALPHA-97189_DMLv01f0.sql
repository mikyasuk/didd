@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S02.01cx_04_ALPHA-97189_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

UPDATE CDERRMESSAGETP SET ERR_MESSAGE = 'The phone number must be 10 digits and the first and fourth digits must be different from 0 and 1.', LAST_UPDATE_DT = SYSDATE WHERE LANG_TP_CD = 100 AND ERR_MESSAGE_TP_CD = 9200067;
UPDATE CDERRMESSAGETP SET ERR_MESSAGE = 'Le numéro de téléphone doit être composé de 10 chiffres, le premier et le quatrième doivent être différents de 0 et 1.', LAST_UPDATE_DT = SYSDATE WHERE LANG_TP_CD = 200 AND ERR_MESSAGE_TP_CD = 9200067;


commit;

set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;
