@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S02.01cx_02_ALPHA-66363_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

INSERT INTO CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT)   
VALUES (100, 9400120, '<parm> is not allowed in the <parm> field.', null,CURRENT_TIMESTAMP);

INSERT INTO CDERRMESSAGETP (LANG_TP_CD, ERR_MESSAGE_TP_CD, ERR_MESSAGE, COMMENTS, LAST_UPDATE_DT)   
VALUES (200, 9400120, '<parm> n''est pas un caractère permis pour le champ <parm>.', null,CURRENT_TIMESTAMP);

INSERT INTO ERRREASON (ERR_REASON_TP_CD, COMPONENT_TYPE_ID, ERR_TYPE_CD, ERR_MESSAGE_TP_CD, ERR_SEVERITY_TP_CD, LAST_UPDATE_DT) 
VALUES (9400120, 4350, 'FVERR', 9400120, null, CURRENT_TIMESTAMP);

commit;

set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;

