@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S02.01cx_01_ALPHA-91750_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

update CDALERTTP set EXPIRY_DT = SYSDATE , LAST_UPDATE_DT=SYSDATE  WHERE ALERT_TP_CD = 1000008;

update CDALERTTP set EXPIRY_DT = SYSDATE , LAST_UPDATE_DT=SYSDATE  WHERE ALERT_TP_CD = 1000009;

update XNBC_PFPP_ADJ_ACTION set PRIORITY_NO = 1, PFPP_RULE_NAME = 'AlertCategoryFinCrimDifferenceA1Downgrade', COLUMN_TP_CD = 1000004, CAT_IND='Y', CAT_TABLE_NAME = 'CDALERTCAT', CAT_COLUMN_NAME='ALERT_CAT_CD', CAT_TP_CD = 1000004, LAST_UPDATE_DT=current_timestamp where PFPP_RULE_ID=1;

update XNBC_PFPP_ADJ_ACTION set PRIORITY_NO = 3, LAST_UPDATE_DT=SYSDATE where PFPP_RULE_ID=6;

update XNBC_PFPP_ADJ_ACTION set PRIORITY_NO = 4, LAST_UPDATE_DT=SYSDATE where PFPP_RULE_ID=2;

update XNBC_PFPP_ADJ_ACTION set PRIORITY_NO = 5, LAST_UPDATE_DT=SYSDATE where PFPP_RULE_ID=3;

update XNBC_PFPP_ADJ_ACTION set PRIORITY_NO = 6, LAST_UPDATE_DT=SYSDATE where PFPP_RULE_ID=4;

update XNBC_PFPP_ADJ_ACTION set PRIORITY_NO = 7, LAST_UPDATE_DT=SYSDATE where PFPP_RULE_ID=5;

insert into XNBC_PFPP_ADJ_ACTION (PFPP_RULE_ID,PFPP_RULE_CODE,PFPP_RULE_NAME,XML_TAG_NAME,PRIORITY_NO,MDM_TABLE_NAME,COLUMN_NAME,COLUMN_TP_CD,ADJ_ACTION_TP_CD,EFFECT_START_DT,CAT_IND,CAT_TABLE_NAME,CAT_COLUMN_NAME,CAT_TP_CD,LAST_UPDATE_DT,LAST_UPDATE_USER,RESOLVE_DUP_ERR_MESSAGE_TP_CD) values(7,'LABEL','AlertCategoryFinCrimDifferenceA1Downgrade','AlertType',2,'ALERT','ALERT_TP_CD',1000005,1000002,TO_DATE('2020-10-28','YYYY-MM-DD'),'Y','CDALERTCAT','ALERT_CAT_CD',1000005,SYSDATE,'mdmadmin',null);

update CDACTIONADJREASTP set NAME= 'Down- One party has a Label of High Risk Category', LAST_UPDATE_DT= SYSDATE where ADJ_ACTION_TP_CD=1000001;

update CDACTIONADJREASTP set NAME= 'Down- One party has a Label of Financial Crime Category', LAST_UPDATE_DT= SYSDATE where ADJ_ACTION_TP_CD=1000002;

update CDERRMESSAGETP set ERR_MESSAGE= 'The action cannot be performed because at least one of the profiles has a label of "High Risk-Financial Crime" category while the other does not.', LAST_UPDATE_DT= SYSDATE where ERR_MESSAGE_TP_CD=9200088 AND LANG_TP_CD=100;

update CDERRMESSAGETP set ERR_MESSAGE= 'Cette action n''est pas autorisée car au moins un des deux profils a une étiquette de catégorie "Haut risque-criminalité financière" alors que l''autre non.', LAST_UPDATE_DT= SYSDATE where ERR_MESSAGE_TP_CD=9200088 AND LANG_TP_CD=200;

commit;

set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;

