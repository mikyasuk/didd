-- Run below SQL for CDALERTTP updates
ALPHA-96795-CDALERTTP-INSERTS.sql

-- Run batch follow below sequence
1. ALPHA-96795-refreshEBXCache-LabelCode_MCPLabelCode.xml

