@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S01.01cx_01_ALPHA-96795-CDALERTTP-INSERTSv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

insert into CDALERTTP values(100,1000048,1000003,'M3-001.00','Means that the party signed an agreement with M3',null,sysdate);
insert into CDALERTTP values(200,1000048,1000003,'M3-001.00','Signifie que le client a signé une entente avec M3',null,sysdate);

commit;


set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;


