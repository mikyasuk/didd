prompt "Start of Rollback 2023 R04.0.4"
/

@ROLLBACK_ALPHA-98446_DML.sql

prompt "End of Rollback 2023 R04.0.4"
/