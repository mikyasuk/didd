@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S04.01cx_01_ALPHA-98446_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

DELETE FROM ERRREASON WHERE ERR_REASON_TP_CD = 9400120;
DELETE FROM CDERRMESSAGETP WHERE ERR_MESSAGE_TP_CD = 9400120;

Commit;
set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;

