prompt "Start of 2023 R04.0.4"
/

@ALPHA-98446_DML.sql

prompt "End of 2023 R04.0.4"
/