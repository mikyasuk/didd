

UPDATE BUSINTERNALTXN SET int_tx_log_ind = 'N', last_update_dt = CURRENT_TIMESTAMP 
WHERE business_tx_tp_cd = 551 AND internal_bus_tx_tp = 263;

UPDATE BUSINTERNALTXN SET int_tx_log_ind = 'N', last_update_dt = CURRENT_TIMESTAMP 
WHERE business_tx_tp_cd = 924 AND internal_bus_tx_tp = 263;

DELETE FROM BUSINTERNALTXN WHERE BUS_INTERN_TXN_ID = 9001001;

COMMIT;