@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S03.01cx_03_ALPHA-98445_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

--ALPHA-98445: Add switch to control creation of FCC default preference
INSERT INTO CONFIGELEMENT (ELEMENT_ID,DEPLOYMENT_ID,NAME,VALUE,VALUE_DEFAULT,LAST_UPDATE_DT,LAST_UPDATE_USER) 
VALUES (1000002, 1006,'/NBC/MCP/Preference/FCCDefaultPreferenceCreation/enabled',null,'false',sysdate,'MDMDEV');

commit;
set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;
