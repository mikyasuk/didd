@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S03.01cx_01_ALPHA-78329_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

UPDATE BUSINTERNALTXN SET int_tx_log_ind = 'Y', last_update_dt = CURRENT_TIMESTAMP 
WHERE business_tx_tp_cd = 551 AND internal_bus_tx_tp = 263;

UPDATE BUSINTERNALTXN SET int_tx_log_ind = 'Y', last_update_dt = CURRENT_TIMESTAMP 
WHERE business_tx_tp_cd = 924 AND internal_bus_tx_tp = 263;

INSERT INTO BUSINTERNALTXN (BUS_INTERN_TXN_ID, BUSINESS_TX_TP_CD, INTERNAL_BUS_TX_TP, INT_TX_LOG_IND, LAST_UPDATE_DT)
VALUES (9001001, 69, 264, 'Y', CURRENT_TIMESTAMP);

commit;
set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;

