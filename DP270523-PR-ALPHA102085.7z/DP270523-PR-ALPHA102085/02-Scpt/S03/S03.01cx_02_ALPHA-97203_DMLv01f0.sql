@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql  'S03.01cx_02_ALPHA-97203_DMLv01f0'
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set current_schema=MDMUSR;
SET echo on;

--ALPHA-97203: error message update
UPDATE CDERRMESSAGETP SET ERR_MESSAGE = 'The relationship identifier is invalid.', LAST_UPDATE_DT = SYSDATE WHERE LANG_TP_CD = 100 AND ERR_MESSAGE_TP_CD = 9000186;
UPDATE CDERRMESSAGETP SET ERR_MESSAGE = 'L''identifiant de la relation est invalide.', LAST_UPDATE_DT = SYSDATE WHERE LANG_TP_CD = 200 AND ERR_MESSAGE_TP_CD = 9000186;

commit;
set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;

