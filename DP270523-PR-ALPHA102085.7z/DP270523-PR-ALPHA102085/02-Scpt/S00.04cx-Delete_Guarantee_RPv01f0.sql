@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_HDR_WrpV1015.sql 'S00.04cx-Delete_Guarantee_RPv01f0';
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
----------------------------------------------------------------------------------
-- v$restore_point columns definition
----------------------------------------------------------------------------------
col GUARANTEE_FLASHBACK_DATABASE for a30
col TIME                         for a31
col PRESERVED                    for a10
col NAME                         for a30
col PDB_RESTORE_POINT            for a17
----------------------------------------------------------------------------------
set echo on;
--WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
--alter session set current_schema=<Any_Schema_Name>;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT &gSpcChr.;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --Delete Restore Point;
PROMPT ----------------------------------------------------------------------------------------------;
-- drop restore point <Restore_Point_Name>;
--create restore point BEFORE_CREATE_TRIGGERS guarantee flashback database;
set echo on;
select name, time, guarantee_flashback_database, preserved, pdb_restore_point from v$restore_point;
drop restore point BEFORE_DEP_ALPHA102085;
select name, time, guarantee_flashback_database, preserved, pdb_restore_point from v$restore_point;
set echo off;
@U:\MCP_Deployment\DP270523-PR-ALPHA102085\05-Wrap\cx220225_FTR_WrpV1015.sql;
