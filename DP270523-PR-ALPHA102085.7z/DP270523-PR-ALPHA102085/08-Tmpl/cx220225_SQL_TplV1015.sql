@H:\Documents\04-Support\04-MCP\08-Deployments\DP220225-PP-ALPHA45308\05-Wrap\cx220225_HDR_WrpV1015.sql '<Script Name No Ext>';
set echo off;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
-- <Set Column Format Here>
set echo on;
--WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
--alter session set current_schema=<Any_Schema_Name>;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT &gSpcChr.;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --<Any Comment Here>;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;

<SQL Code Here>;

set echo off;
@H:\Documents\04-Support\04-MCP\08-Deployments\DP220225-PP-ALPHA45308\05-Wrap\cx220225_FTR_WrpV1015.sql;
