@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql '00-STATS-THINPUB_KAFKA_EVENT_FULL_PROFILE-V01_ts'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
----------------------------------------
--VIEW: MDMPUB STATS
----------------------------------------
column audit_type				for a12
column os_username				for a12
column userhost					for a17
column terminal					for a15
column dbusername				for a10
column client_program_name		for a20
column event_timestamp			for a25
column action_name				for a25
column object_schema			for a15
column object_name				for a30
column system_privilege_used	for a22
column current_user				for a15
column unified_audit_policies	for a25
----------------------------------------
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --<Script Name Here>.sql;
PROMPT ----------------------------------------------------------------------------------------------;
----------------------------------------------
-- Component type
----------------------------------------------
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #01 THINPUB  current table size;
PROMPT ---------------------------------------------------------;
set echo on;
 

 select segment_name as Table_Name,sum( SIZE_GB) as "SIZE_GB" from ( select
owner as "Schema"
, segment_name 
, segment_type 
, round(bytes/1024/1024/1024,2)  as SIZE_GB
, tablespace_name 
from dba_segments
where segment_name='THINPUB'
and owner='MDMPUB')
group by segment_name;

set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #02 Total count THINPUB table;
PROMPT ---------------------------------------------------------;
set echo on;
 
SELECT count(*) FROM MDMPUB.THINPUB;

set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #03 Total count of one month old data or older THINPUB;
PROMPT ---------------------------------------------------------;
set echo on;
 
SELECT count(*) FROM MDMPUB.THINPUB WHERE add_months(INSERTION_DATE , 1) < sysdate ORDER BY INSERTION_DATE  DESC;

set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #04 THINPUB oldest data avaliable;
PROMPT ---------------------------------------------------------;
set echo on;


SELECT min(INSERTION_DATE) FROM MDMPUB.THINPUB WHERE add_months(INSERTION_DATE , 1) < sysdate ORDER BY INSERTION_DATE  DESC;


set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #05 KAFKA_EVENT_FULL_PROFILE  current table size;
PROMPT ---------------------------------------------------------;
set echo on;


 select segment_name as Table_Name,sum( SIZE_GB) as "SIZE_GB" from ( select
owner as "Schema"
, segment_name 
, segment_type 
, round(bytes/1024/1024/1024,2)  as SIZE_GB
, tablespace_name 
from dba_segments
where segment_name='KAFKA_EVENT_FULL_PROFILE'
and owner='MDMPUB')
group by segment_name;


set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #06 Total count KAFKA_EVENT_FULL_PROFILE table;
PROMPT ---------------------------------------------------------;
set echo on;
 

SELECT count(*) FROM MDMPUB.KAFKA_EVENT_FULL_PROFILE;
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #07 Total count of one month old data or older KAFKA_EVENT_FULL_PROFILE;
PROMPT ---------------------------------------------------------;
set echo on;


SELECT count(*) FROM MDMPUB.KAFKA_EVENT_FULL_PROFILE kefp WHERE add_months(PUB_LAST_ACTION_DATE, 1) < sysdate ORDER BY PUB_LAST_ACTION_DATE  DESC;

set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #08 KAFKA_EVENT_FULL_PROFILE oldest data avaliable;
PROMPT ---------------------------------------------------------;
set echo on;


SELECT min(PUB_LAST_ACTION_DATE) FROM MDMPUB.KAFKA_EVENT_FULL_PROFILE;

set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #09 table space size for MDMPUBTBS tablespace in GB;
PROMPT ---------------------------------------------------------;
set echo on;


select * from (
select    tbs.tablespace_name,
tot.bytes/1024/1024/1024 total_GB,
tot.bytes/1024/1024/1024-sum(nvl(fre.bytes,0))/1024/1024/1024  used_GB,
sum(nvl(fre.bytes,0))/1024/1024/1024  free_GB,
(1-sum(nvl(fre.bytes,0))/tot.bytes)*100 pct
from      dba_free_space fre,
(select  tablespace_name, sum(bytes) bytes
from      dba_data_files
group by tablespace_name) tot,
dba_tablespaces tbs
where   tot.tablespace_name    = tbs.tablespace_name
and        fre.tablespace_name(+) = tbs.tablespace_name
group by tbs.tablespace_name, tot.bytes/1024/1024/1024 , tot.bytes
union
select    tsh.tablespace_name,
dtf.bytes/1024/1024/1024 total_GB,
sum(nvl(tsh.bytes_used,0))/1024/1024/1024 used_GB,
sum(nvl(tsh.bytes_free,0))/1024/1024/1024 free_GB,
(1-sum(nvl(tsh.bytes_free,0))/dtf.bytes)*100 pct
from             v$temp_space_header tsh,
(select tablespace_name, sum(bytes) bytes
from dba_temp_files
group by tablespace_name) dtf
where   dtf.tablespace_name     = tsh.tablespace_name(+)
group by tsh.tablespace_name, dtf.bytes/1024/1024/1024 , dtf.bytes
order by 1)
where tablespace_name='MDMPUBTBS';

set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- STATS #10 INDEX list for MDMPUB tables ;
PROMPT ---------------------------------------------------------;
set echo on;


select ind.index_name,
       ind_col.column_name,
       ind.index_type,
       ind.uniqueness,
       ind.table_owner as schema_name,
       ind.table_name as object_name,
       ind.table_type as object_type       
from sys.all_indexes ind
inner join sys.all_ind_columns ind_col on ind.owner = ind_col.index_owner
                                    and ind.index_name = ind_col.index_name
--excluding some Oracle maintained schemas;
where ind.owner not in ('MDMPUB')
and ind.table_name in ('KAFKA_EVENT_FULL_PROFILE','THINPUB','KAFKA_LATEST_FULL_PROFILE')
order by ind.table_owner,
         ind.table_name,
         ind.index_name,
         ind_col.column_position;
         
set echo off;
@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql
