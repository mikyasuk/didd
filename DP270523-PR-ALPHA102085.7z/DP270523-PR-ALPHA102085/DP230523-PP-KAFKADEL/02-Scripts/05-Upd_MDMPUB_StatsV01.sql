@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql  '06-Upd_MDMPUB_StatsV01'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Gather_Schema_Stats;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;

--exec dbms_stats.gather_database_stats(degree => 16, cascade => TRUE);
exec dbms_stats.gather_schema_stats('MDMPUB',degree => 16);

set echo off;
@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql
