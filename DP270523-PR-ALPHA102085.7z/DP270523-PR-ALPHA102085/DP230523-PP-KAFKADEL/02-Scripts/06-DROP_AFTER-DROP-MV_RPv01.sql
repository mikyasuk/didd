@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql '06-DROP_AFTER-DROP-MV_RPv01'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
-- v$restore_point columns definition
----------------------------------------------------------------------------------
col GUARANTEE_FLASHBACK_DATABASE for a30
col TIME                         for a31
col PRESERVED                    for a10
col NAME                         for a30
col PDB_RESTORE_POINT            for a17
----------------------------------------------------------------------------------
-- drop restore point <Restore_Point_Name>;                                                      -- Select Appropriate Command
set echo on;

select name, time, guarantee_flashback_database, preserved, pdb_restore_point from v$restore_point;
drop restore point BEFORE_DROP_MV30MARCH  ;                   -- Select Appropriate Command
select name, time, guarantee_flashback_database, preserved, pdb_restore_point from v$restore_point;

set echo off;
@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql
