-- generate Drop partition older than 30 days for thinpub
select 'ALTER TABLE THINPUB DROP PARTITION ' || partition_name|| ' ;' as PURGE_script from (
WITH date_partition AS (
select partition_name,
  TO_DATE(substr(high_value,11,11),'YYYY-MM-DD') high_value from ( SELECT
    partition_name,
    extractvalue(dbms_xmlgen.getxmltype('select high_value
       FROM   dba_TAB_PARTITIONS WHERE table_name = '''
        || t.table_name
        || ''' and PARTITION_NAME = '''
        || t.partition_name
        || ''''),'//text()') AS high_value
FROM
    dba_tab_partitions t
   WHERE TABLE_NAME = 'THINPUB' and table_owner = 'MDMPUB')
 ) 
 --,final_result
  (SELECT
  partition_name,
   high_value
FROM
date_partition where HIGH_VALUE < SYSDATE -30  and partition_name like '%SYS%'
) order by HIGH_VALUE);
 
 
-- generate Drop partition older than 30 days for KAFKA_EVENT_FULL_PROFILE
select 'ALTER TABLE KAFKA_EVENT_FULL_PROFILE DROP PARTITION ' || partition_name|| ' ;' as PURGE_script from (
WITH date_partition AS (
select partition_name,
  TO_DATE(substr(high_value,11,11),'YYYY-MM-DD') high_value from ( SELECT
    partition_name,
    extractvalue(dbms_xmlgen.getxmltype('select high_value
       FROM   dba_TAB_PARTITIONS WHERE table_name = '''
        || t.table_name
        || ''' and PARTITION_NAME = '''
        || t.partition_name
        || ''''),'//text()') AS high_value
FROM
    dba_tab_partitions t
   WHERE TABLE_NAME = 'KAFKA_EVENT_FULL_PROFILE' and table_owner = 'MDMPUB')
 ) 
 --,final_result
  (SELECT
  partition_name,
   high_value
FROM
date_partition where HIGH_VALUE < SYSDATE -30  and partition_name like '%SYS%'
) order by HIGH_VALUE);
 