@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql '04-KAFKA-DROP-PARTITION-KAFKA_EVENT_FULL_PROFILE-V01'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --<Script Name Here>.sql;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;



set echo off;
@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql