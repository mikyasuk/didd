@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrap\cx220225_HDR_WrpV1015.sql  'S00.03cx-Rebuilt_MDM_RolesV01f0'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
SET echo		off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Grants to RL_MDMUSR_READONLY and RL_MDMUSR_READWRITE
PROMPT ----------------------------------------------------------------------------------------------;
SET echo		off;
DECLARE
--DROP_KAFKA_EVENT_FULL_PROFILE varchar2(500);
DROP_THINPUB varchar2(500);
trg_schema varchar2(30) := upper('MDMPUB');
--trg_KAFKA_EVENT_FULL_PROFILE varchar2(30) := upper('KAFKA_EVENT_FULL_PROFILE');
trg_THINPUB varchar2(30) := upper('THINPUB');
BEGIN
	FOR cur_rec IN (WITH date_partition AS (
select partition_name,
  TO_DATE(substr(high_value,11,11),'YYYY-MM-DD') high_value from ( SELECT
    partition_name,
    extractvalue(dbms_xmlgen.getxmltype('select high_value
       FROM   dba_TAB_PARTITIONS WHERE table_name = '''
        || t.table_name
        || ''' and PARTITION_NAME = '''
        || t.partition_name
        || ''''),'//text()') AS high_value
FROM
    dba_tab_partitions t
   WHERE TABLE_NAME = ' ||trg_THINPUB||' and table_owner = ' ||trg_schema||')
 ) 
 --,final_result
  (SELECT
  partition_name,
   high_value
FROM
date_partition where HIGH_VALUE < SYSDATE -30  and partition_name like '%SYS%'
) order by HIGH_VALUE) LOOP
		BEGIN
			DROP_THINPUB:='ALTER TABLE  ' ||trg_schema||'.' || cur_rec.table_name || ' DROP PARTITION '||partition_name;
			--grant_RW_str:='GRANT SELECT, INSERT,UPDATE,DELETE ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RW_role;
			--execute immediate DROP_THINPUB;
			--execute immediate grant_RW_str;
		END;
	END LOOP;
	dbms_output.put_line('Grants to '||trg_RO_role||' and '||trg_RW_role||' Completed Successfully!');
END;
/
/*
SET echo		on;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT -- Grants to RL_MDMPUB_READONLY and RL_MDMPUB_READWRITE
PROMPT ----------------------------------------------------------------------------------------------;
SET echo		off;
DECLARE
grant_RO_str varchar2(500);
grant_RW_str varchar2(500);
trg_schema varchar2(30) := upper('MDMPUB');
trg_RO_role varchar2(30) := upper('RL_MDMPUB_READONLY');
trg_RW_role varchar2(30) := upper('RL_MDMPUB_READWRITE');
BEGIN
	FOR cur_rec IN (SELECT table_name FROM dba_tables where owner = ''||trg_schema||'' order by table_name) LOOP
		BEGIN
			grant_RO_str:='GRANT SELECT ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RO_role;
		--	grant_RW_str:='GRANT SELECT, INSERT,UPDATE,DELETE ON  ' ||trg_schema||'.' || cur_rec.table_name || ' TO '||trg_RW_role;
			execute immediate grant_RO_str;
			execute immediate grant_RW_str;
		END;
	END LOOP;
	--execute immediate 'GRANT SELECT ON MDMPUB.KAFKA_EVENT_FULL_PROF_SID  to RL_MDMPUB_READONLY, RL_MDMPUB_READWRITE';
	--execute immediate 'GRANT SELECT ON MDMPUB.KAFKA_LATEST_FULL_PROF_SID  to RL_MDMPUB_READONLY, RL_MDMPUB_READWRITE';
	--execute immediate 'GRANT SELECT ON MDMPUB.THINPUB_SID to RL_MDMPUB_READONLY, RL_MDMPUB_READWRITE';
	dbms_output.put_line('Grants to '||trg_RO_role||' and '||trg_RW_role||' Completed Successfully!');
END;
/*/
set echo off;
@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrap\cx220225_FTR_WrpV1015.sql;
