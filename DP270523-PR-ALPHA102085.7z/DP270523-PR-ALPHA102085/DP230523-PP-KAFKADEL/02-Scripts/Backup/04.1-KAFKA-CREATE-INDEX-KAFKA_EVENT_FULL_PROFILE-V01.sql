@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql '04.0-KAFKA-CREATE-INDEX-KAFKA_EVENT_FULL_PROFILE-V01'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --<Script Name Here>.sql;
PROMPT ----------------------------------------------------------------------------------------------;
DROP INDEX MDMPUB.IX_KAFKA_EVENT_FULL_PRO_03;
CREATE INDEX MDMPUB.IX_KAFKA_EVENT_FULL_PRO_03 ON MDMPUB.KAFKA_EVENT_FULL_PROFILE
(ENTITY_ID)
LOGGING
TABLESPACE MDMPUBTBS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );
DROP INDEX MDMPUB.IX_KAFKA_EVENT_FULL_PRO_04;
CREATE INDEX MDMPUB.IX_KAFKA_EVENT_FULL_PRO_04 ON MDMPUB.KAFKA_EVENT_FULL_PROFILE
(SERVER_ID, PUB_STATUS, PUB_LOCK)
LOGGING
TABLESPACE MDMPUBTBS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );
DROP INDEX MDMPUB.IX_KAFKA_EVENT_FULL_PRO_05;
CREATE INDEX MDMPUB.IX_KAFKA_EVENT_FULL_PRO_05 ON MDMPUB.KAFKA_EVENT_FULL_PROFILE
(PUB_STATUS)
LOGGING
TABLESPACE MDMPUBTBS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );


set echo off;
@U:\MCP_Deployment\DP230523-PP-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql