
set echo off head on feedback off timing off linesize 114;
SELECT upper(sys_context('USERENV','CON_NAME'))||'('||DECODE(UPPER(sys_context('USERENV','DATABASE_ROLE')),'PRIMARY','RW','RO')||'): USER('||rpad(SYS_CONTEXT('USERENV','CURRENT_USER'),18)||') SID('||lpad(SYS_CONTEXT('USERENV','UNIFIED_AUDIT_SESSIONID'),10)||') "On '||(CASE when '&_O_VERSION.' like '%Extreme%' then 'Exacc' else ' AIX ' END)||' With Oracle V'||'&_O_RELEASE.'||'" --> '||SYSDATE as " " FROM DUAL;
PROMPT ------------------------------------------------------------------------------------------------------------------;
SPOOL OFF;
exit;
