set escchar @ termout on feedback off show off verify off trim off trims off linesize 114 serveroutput on size unlimited;
DEFINE ScriptName = "'&1'"                             				-- Provide Script Name
DEFINE LogPath = "'U:\MCP_Deployment\DP230523-PP-KAFKADEL\03-Logs\'" -- Comment if Run from Unix
--DEFINE LogPath = "'<JumpServer_Unix_NFS_Path>/02-Scripts/'"       						-- Comment if Run from TOAD
COLUMN LogFile new_value _LogFile
ALTER SESSION SET nls_date_format='YY-MM-DD HH24:MI:SS';
SELECT &LogPath.||&ScriptName.||'~'||TO_CHAR(SYSDATE, 'YY"-"MM"-"DD@HH24"h"MI"m"SS"s"')||'.log' LogFile FROM DUAL;
SPOOL "&_LogFile.";
SELECT upper(sys_context('USERENV','CON_NAME'))||'('||DECODE(UPPER(sys_context('USERENV','DATABASE_ROLE')),'PRIMARY','RW','RO')||'): USER('||rpad(SYS_CONTEXT('USERENV','CURRENT_USER'),18)||') SID('||lpad(SYS_CONTEXT('USERENV','UNIFIED_AUDIT_SESSIONID'),10)||') "On '||(CASE when '&_O_VERSION.' like '%Extreme%' then 'Exacc' else ' AIX ' END)||' With Oracle V'||'&_O_RELEASE.'||'" --> '||SYSDATE as " " FROM DUAL;
PROMPT ------------------------------------------------------------------------------------------------------------------;
set escchar off linesize 2000 pagesize 2000 long 5000 head on feedback on echo off;

PROMPT ---------------------------------------------------------;
PROMPT -- Set Session Parameters
PROMPT ---------------------------------------------------------;
set echo on;

WHENEVER OSERROR EXIT 9;
--WHENEVER SQLERROR CONTINUE;

alter session force parallel dml   parallel 16;
alter session force parallel query parallel 16;

