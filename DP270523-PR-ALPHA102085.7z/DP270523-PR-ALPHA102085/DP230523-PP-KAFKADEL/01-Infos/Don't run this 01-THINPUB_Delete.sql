@U:\MCP_Deployment\DP210722-P-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql '01-THINPUB_Delete'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --<Script Name Here>.sql;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;----------------------------------------------
-- Component type
----------------------------------------------
---Total count of one month old data or older THINPUB
SELECT count(*) FROM MDMPUB.THINPUB WHERE add_months(INSERTION_DATE , 2) < sysdate ORDER BY INSERTION_DATE  DESC;

----Delete  one  month old data or older THINPUB
DELETE FROM MDMPUB.THINPUB WHERE add_months(INSERTION_DATE , 2) < sysdate;
commit;

---Total count of one month old data or older THINPUB
SELECT count(*) FROM MDMPUB.THINPUB WHERE add_months(INSERTION_DATE , 2) < sysdate ORDER BY INSERTION_DATE  DESC;
set echo off;
@U:\MCP_Deployment\DP210722-P-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql
