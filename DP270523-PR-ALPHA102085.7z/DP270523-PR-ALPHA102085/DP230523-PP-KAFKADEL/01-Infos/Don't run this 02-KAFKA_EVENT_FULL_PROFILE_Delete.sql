@U:\MCP_Deployment\DP210722-P-KAFKADEL\05-Wrappers\SR210706_HeaderV01.sql '02-KAFKA_EVENT_FULL_PROFILE_Delete'
set echo off;
PROMPT ---------------------------------------------------------;
PROMPT -- Set Additional Session Parameters;
PROMPT ---------------------------------------------------------;
set echo on;
WHENEVER SQLERROR CONTINUE;
alter session disable parallel dml;
alter session disable parallel query;
alter session set NLS_LENGTH_SEMANTICS='CHAR';
alter session set current_schema=MDMPUB;
set echo off;
PROMPT ----------------------------------------------------------------------------------------------;
PROMPT --<Script Name Here>.sql;
PROMPT ----------------------------------------------------------------------------------------------;
set echo on;----------------------------------------------
-- Component type
----------------------------------------------
---Total count of one month old data or older KAFKA_EVENT_FULL_PROFILE
SELECT count(*) FROM MDMPUB.KAFKA_EVENT_FULL_PROFILE kefp WHERE add_months(PUB_LAST_ACTION_DATE, 2) < sysdate ORDER BY PUB_LAST_ACTION_DATE  DESC;

----Delete  one  month old data or older KAFKA_EVENT_FULL_PROFILE
DELETE FROM MDMPUB.KAFKA_EVENT_FULL_PROFILE kefp WHERE add_months(PUB_LAST_ACTION_DATE, 2) < sysdate;
commit;

---Total count of one month old data or older KAFKA_EVENT_FULL_PROFILE
SELECT count(*) FROM MDMPUB.KAFKA_EVENT_FULL_PROFILE kefp WHERE add_months(PUB_LAST_ACTION_DATE, 2) < sysdate ORDER BY PUB_LAST_ACTION_DATE  DESC;
set echo off;
@U:\MCP_Deployment\DP210722-P-KAFKADEL\05-Wrappers\SR210706_FooterV01.sql
