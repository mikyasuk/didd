prompt "Start of R09 P2"
/
@M1etadata-R09/Rollback_TAN-1290-DML.sql

@1Metadata-R09/ALPHA-21414_NBCMCPPartyData_TRIGGERS.sql

@1Metadata-R09/TAN-1290-DML.sql

@1Metadata-R09/ALPHA-24583-DML.sql

prompt "End of R09 P2"
/
