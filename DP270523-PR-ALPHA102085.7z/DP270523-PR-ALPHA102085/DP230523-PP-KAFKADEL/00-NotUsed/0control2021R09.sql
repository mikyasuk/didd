prompt "Start of R09"
/

@0Metadata-R09/TAN-1757_SETUP.sql
@0Metadata-R09/TAN-1757_TRIGGERS.sql
@0Metadata-R09/ALPHA-21414_NBCMCPPartyData_SETUP.sql
@0Metadata-R09/ALPHA-21414_NBCMCPPartyData_TRIGGERS.sql
@0Metadata-R09/ALPHA-22299_PROCESSINGPURPOSE_DDL.sql

@0Metadata-R09/TAN-1757_0Metadata_DML.sql
@0Metadata-R09/TAN-1290-CONFIG.sql
@0Metadata-R09/TAN-1290-DML.sql
@0Metadata-R09/TAN-1290-ErrMsg-DML.sql
@0Metadata-R09/ALPHA-22299_PROCESSINGPURPOSE_DML.sql
@0Metadata-R09/ALPHA-21080-DML.sql
@0Metadata-R09/ALPHA-21080-ErrMsg-DML.sql
@0Metadata-R09/ALPHA-21370-DML.sql
@0Metadata-R09/ALPHA-21370-ErrMsg-DML.sql
@0Metadata-R09/ALPHA-21414_NBCMCPPartyData_0Metadata.sql
@0Metadata-R09/ALPHA-22283-ErrMsg-DML.sql

prompt "End of R09"
/
